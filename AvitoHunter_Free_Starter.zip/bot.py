import os, json, asyncio, logging
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

TOKEN=os.getenv("TELEGRAM_BOT_TOKEN")
logging.basicConfig(level=logging.INFO)
LIMITS={"15 Pro":40000,"15 Pro Max":45000,"16 Pro":55000,"16 Pro Max":60000,"17 Pro":70000,"17 Pro Max":80000}
BAD_WORDS=["не работает","неисправ","face id не","фейс айди не","разбит","битый","на запчасти","утоплен","после ремонта","icloud","заблокирован"]

async def start(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📱 Avito iPhone Hunter SPB\n\n"
        "Тестовая бесплатная версия запущена.\n"
        "Автоматический сбор объявлений пока не подключён — нужен разрешённый источник данных.\n\n"
        "Команды: /prices /status"
    )
async def prices(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("💰 Лимиты:\n"+"\n".join(f"iPhone {m}: до {p:,} ₽".replace(",", " ") for m,p in LIMITS.items()))
async def status(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🟢 Telegram-бот отвечает. Мониторинг Авито не подключён.")
def main():
    if not TOKEN: raise RuntimeError("Set TELEGRAM_BOT_TOKEN environment variable")
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start)); app.add_handler(CommandHandler("prices",prices)); app.add_handler(CommandHandler("status",status))
    app.run_polling()
if __name__=="__main__": main()
